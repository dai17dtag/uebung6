package main;

import gui.MyGUI;

public class Main
{
    public static void main(String[] args)
    {
        MyGUI gui = new MyGUI();
    }
}
